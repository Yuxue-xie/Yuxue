# 玉雪工作台 · GitHub Pages 部署包

## 这个文件夹是什么
把整个 `yuxue-gh-pages` 文件夹上传到 GitHub 仓库并开启 Pages，就能得到一个 `https://` 网址，
然后在 iPhone Safari 里「添加到主屏幕」，即可获得带 ❄️ 图标的全屏 App。

## 文件清单
- `index.html` —— 工作台页面（主页）
- `manifest.json` —— PWA 配置（App 名称「玉雪」、图标、全屏模式）
- `apple-touch-icon.png` —— iOS 添加到主屏幕用的图标
- `icon/` —— 各尺寸图标

## 部署步骤（网页操作，约 3 分钟）
1. 打开 https://github.com/new 登录你的 GitHub 账号
   - Repository name 随意，如 `yuxue`
   - 选 **Public**（Pages 免费版要求公开）
   - 点 **Create repository**
2. 在新建的仓库页，点 **uploading an existing file**（上传已有文件）
3. 把本文件夹里的 `index.html`、`manifest.json`、`apple-touch-icon.png` 和 `icon` 文件夹
   全部拖进上传区，等上传完成，点 **Commit changes**
4. 打开仓库的 **Settings → Pages**（左侧栏）
   - Source 选 **Deploy from a branch**
   - Branch 选 **main** / 目录 **/(root)** → **Save**
5. 等 1~2 分钟，页面顶部会显示网址：
   `https://你的用户名.github.io/yuxue/`
   打开确认工作台能正常显示

## 添加到 iPhone 桌面
1. iPhone 用 **Safari** 打开上面的网址
2. 点底部 **分享 ⬆️** → **「添加到主屏幕」**
3. 名称保持 **玉雪** → 添加
4. 桌面出现 ❄️ 图标，点开即全屏运行 ✨

## 数据说明
- 所有数据保存在浏览器本地（localStorage），不上传任何服务器
- 换手机或换浏览器前，请在工作台「📲 装到桌面」页导出备份码 / 下载备份文件
